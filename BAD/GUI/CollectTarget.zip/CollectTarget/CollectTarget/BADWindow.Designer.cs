﻿namespace CollectTarget
{
    partial class BADWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.continueButton = new System.Windows.Forms.Button();
            this.imageList = new System.Windows.Forms.CheckedListBox();
            this.browse = new System.Windows.Forms.Button();
            this.imageName = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.errorMessage = new System.Windows.Forms.RichTextBox();
            this.imagePreview = new System.Windows.Forms.PictureBox();
            this.ftpAddressTb = new System.Windows.Forms.TextBox();
            this.ftpPskTb = new System.Windows.Forms.TextBox();
            this.ftpAddressLabel = new System.Windows.Forms.Label();
            this.ftpPskLabel = new System.Windows.Forms.Label();
            this.userLabel = new System.Windows.Forms.Label();
            this.ftpUserTb = new System.Windows.Forms.TextBox();
            this.ftpGb = new System.Windows.Forms.GroupBox();
            this.testFtpButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.usbCameraRb = new System.Windows.Forms.RadioButton();
            this.goProRb = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.imagePreview)).BeginInit();
            this.ftpGb.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // continueButton
            // 
            this.continueButton.Enabled = false;
            this.continueButton.Location = new System.Drawing.Point(544, 468);
            this.continueButton.Name = "continueButton";
            this.continueButton.Size = new System.Drawing.Size(75, 23);
            this.continueButton.TabIndex = 8;
            this.continueButton.Text = "Continue";
            this.continueButton.UseVisualStyleBackColor = true;
            this.continueButton.Click += new System.EventHandler(this.continueButton_Click);
            // 
            // imageList
            // 
            this.imageList.FormattingEnabled = true;
            this.imageList.Location = new System.Drawing.Point(11, 171);
            this.imageList.Name = "imageList";
            this.imageList.Size = new System.Drawing.Size(383, 139);
            this.imageList.TabIndex = 11;
            this.imageList.SelectedIndexChanged += new System.EventHandler(this.imageList_SelectedIndexChanged);
            // 
            // browse
            // 
            this.browse.Location = new System.Drawing.Point(11, 138);
            this.browse.Name = "browse";
            this.browse.Size = new System.Drawing.Size(75, 23);
            this.browse.TabIndex = 13;
            this.browse.Text = "Browse";
            this.browse.UseVisualStyleBackColor = true;
            this.browse.Click += new System.EventHandler(this.browse_Click);
            // 
            // imageName
            // 
            this.imageName.Enabled = false;
            this.imageName.ForeColor = System.Drawing.Color.ForestGreen;
            this.imageName.Location = new System.Drawing.Point(92, 140);
            this.imageName.Name = "imageName";
            this.imageName.Size = new System.Drawing.Size(221, 20);
            this.imageName.TabIndex = 14;
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(319, 138);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 15;
            this.button1.Text = "Add Target";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // errorMessage
            // 
            this.errorMessage.Enabled = false;
            this.errorMessage.ForeColor = System.Drawing.Color.Red;
            this.errorMessage.Location = new System.Drawing.Point(11, 344);
            this.errorMessage.Name = "errorMessage";
            this.errorMessage.Size = new System.Drawing.Size(608, 118);
            this.errorMessage.TabIndex = 16;
            this.errorMessage.Text = "";
            // 
            // imagePreview
            // 
            this.imagePreview.BackColor = System.Drawing.SystemColors.ControlLight;
            this.imagePreview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.imagePreview.Location = new System.Drawing.Point(436, 140);
            this.imagePreview.Name = "imagePreview";
            this.imagePreview.Size = new System.Drawing.Size(172, 170);
            this.imagePreview.TabIndex = 17;
            this.imagePreview.TabStop = false;
            // 
            // ftpAddressTb
            // 
            this.ftpAddressTb.ForeColor = System.Drawing.Color.ForestGreen;
            this.ftpAddressTb.Location = new System.Drawing.Point(92, 38);
            this.ftpAddressTb.Name = "ftpAddressTb";
            this.ftpAddressTb.Size = new System.Drawing.Size(221, 20);
            this.ftpAddressTb.TabIndex = 18;
            this.ftpAddressTb.Text = "ftp://ndrives.calu.edu";
            this.ftpAddressTb.TextChanged += new System.EventHandler(this.ftpAddressTb_TextChanged);
            // 
            // ftpPskTb
            // 
            this.ftpPskTb.ForeColor = System.Drawing.Color.ForestGreen;
            this.ftpPskTb.Location = new System.Drawing.Point(92, 85);
            this.ftpPskTb.Name = "ftpPskTb";
            this.ftpPskTb.PasswordChar = '*';
            this.ftpPskTb.Size = new System.Drawing.Size(221, 20);
            this.ftpPskTb.TabIndex = 20;
            this.ftpPskTb.Text = "Pbhmount18";
            this.ftpPskTb.TextChanged += new System.EventHandler(this.ftpPskTb_TextChanged);
            // 
            // ftpAddressLabel
            // 
            this.ftpAddressLabel.AutoSize = true;
            this.ftpAddressLabel.Location = new System.Drawing.Point(18, 41);
            this.ftpAddressLabel.Name = "ftpAddressLabel";
            this.ftpAddressLabel.Size = new System.Drawing.Size(68, 13);
            this.ftpAddressLabel.TabIndex = 21;
            this.ftpAddressLabel.Text = "FTP Address";
            // 
            // ftpPskLabel
            // 
            this.ftpPskLabel.AutoSize = true;
            this.ftpPskLabel.Location = new System.Drawing.Point(18, 85);
            this.ftpPskLabel.Name = "ftpPskLabel";
            this.ftpPskLabel.Size = new System.Drawing.Size(53, 13);
            this.ftpPskLabel.TabIndex = 22;
            this.ftpPskLabel.Text = "Password";
            // 
            // userLabel
            // 
            this.userLabel.AutoSize = true;
            this.userLabel.Location = new System.Drawing.Point(18, 62);
            this.userLabel.Name = "userLabel";
            this.userLabel.Size = new System.Drawing.Size(55, 13);
            this.userLabel.TabIndex = 24;
            this.userLabel.Text = "Username";
            // 
            // ftpUserTb
            // 
            this.ftpUserTb.ForeColor = System.Drawing.Color.ForestGreen;
            this.ftpUserTb.Location = new System.Drawing.Point(92, 62);
            this.ftpUserTb.Name = "ftpUserTb";
            this.ftpUserTb.Size = new System.Drawing.Size(221, 20);
            this.ftpUserTb.TabIndex = 25;
            this.ftpUserTb.Text = "hah5158";
            // 
            // ftpGb
            // 
            this.ftpGb.Controls.Add(this.testFtpButton);
            this.ftpGb.Location = new System.Drawing.Point(12, 12);
            this.ftpGb.Name = "ftpGb";
            this.ftpGb.Size = new System.Drawing.Size(393, 111);
            this.ftpGb.TabIndex = 26;
            this.ftpGb.TabStop = false;
            this.ftpGb.Text = "FTP Settings";
            // 
            // testFtpButton
            // 
            this.testFtpButton.Location = new System.Drawing.Point(307, 71);
            this.testFtpButton.Name = "testFtpButton";
            this.testFtpButton.Size = new System.Drawing.Size(75, 23);
            this.testFtpButton.TabIndex = 19;
            this.testFtpButton.Text = "Test";
            this.testFtpButton.UseVisualStyleBackColor = true;
            this.testFtpButton.Click += new System.EventHandler(this.testFtpButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.usbCameraRb);
            this.groupBox1.Controls.Add(this.goProRb);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Location = new System.Drawing.Point(436, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(172, 111);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Camera Types";
            // 
            // usbCameraRb
            // 
            this.usbCameraRb.AutoSize = true;
            this.usbCameraRb.Location = new System.Drawing.Point(6, 42);
            this.usbCameraRb.Name = "usbCameraRb";
            this.usbCameraRb.Size = new System.Drawing.Size(86, 17);
            this.usbCameraRb.TabIndex = 28;
            this.usbCameraRb.Text = "USB Camera";
            this.usbCameraRb.UseVisualStyleBackColor = true;
            // 
            // goProRb
            // 
            this.goProRb.AutoSize = true;
            this.goProRb.Checked = true;
            this.goProRb.Location = new System.Drawing.Point(6, 19);
            this.goProRb.Name = "goProRb";
            this.goProRb.Size = new System.Drawing.Size(55, 17);
            this.goProRb.TabIndex = 27;
            this.goProRb.TabStop = true;
            this.goProRb.Text = "GoPro";
            this.goProRb.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(307, 71);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 19;
            this.button2.Text = "Test";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // BADWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(633, 499);
            this.Controls.Add(this.ftpUserTb);
            this.Controls.Add(this.userLabel);
            this.Controls.Add(this.ftpPskLabel);
            this.Controls.Add(this.ftpAddressLabel);
            this.Controls.Add(this.ftpPskTb);
            this.Controls.Add(this.ftpAddressTb);
            this.Controls.Add(this.imagePreview);
            this.Controls.Add(this.errorMessage);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.imageName);
            this.Controls.Add(this.browse);
            this.Controls.Add(this.imageList);
            this.Controls.Add(this.continueButton);
            this.Controls.Add(this.ftpGb);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "BADWindow";
            this.Text = "B.A.D.";
            this.Load += new System.EventHandler(this.BADWindow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imagePreview)).EndInit();
            this.ftpGb.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button continueButton;
        private System.Windows.Forms.CheckedListBox imageList;
        private System.Windows.Forms.Button browse;
        private System.Windows.Forms.TextBox imageName;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox errorMessage;
        private System.Windows.Forms.PictureBox imagePreview;
        private System.Windows.Forms.TextBox ftpAddressTb;
        private System.Windows.Forms.TextBox ftpPskTb;
        private System.Windows.Forms.Label ftpAddressLabel;
        private System.Windows.Forms.Label ftpPskLabel;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.TextBox ftpUserTb;
        private System.Windows.Forms.GroupBox ftpGb;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton usbCameraRb;
        private System.Windows.Forms.RadioButton goProRb;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button testFtpButton;
    }
}

