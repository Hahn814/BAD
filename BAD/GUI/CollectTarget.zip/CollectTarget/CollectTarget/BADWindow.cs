﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollectTarget
{
    public partial class BADWindow : Form
    {
        public BADWindow()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void updateDirectory_Click(object sender, EventArgs e)
        {
            //method to update the current directory and re-populate the image directory list
        }

        private void continueButton_Click(object sender, EventArgs e)
        {
            //method to test for validity and upload target to edison 
        }

        private void BADWindow_Load(object sender, EventArgs e)
        {

        }
    }
}
