﻿using InTheHand.Net;
using InTheHand.Net.Bluetooth;
using InTheHand.Net.Sockets;
using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Windows.Forms;

namespace CollectTarget
{
    public partial class BADWindow : Form
    {
        private string currentDirectory = "";
        private string file, fullPath;
        private string ftpURL = "ftp://ndrives.calu.edu";
        private string username = "hah5158";
        private string password = "Pbhmount18";

        private bool noneSelected = false;
        public BADWindow()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void updateDirectory_Click(object sender, EventArgs e)
        {
            //method to update the current directory and re-populate the image directory list
        }

        private void continueButton_Click(object sender, EventArgs e)
        {
            //method to test for validity and upload target to edison 
            errorMessage.ForeColor = Color.Black;
            errorMessage.Text = "Initializing communications with Edison..";

                try
            {
                // Get the object used to communicate with the server.
                FileInfo fi = new FileInfo(fullPath);
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpURL + "/" + fi.Name);
                request.Method = WebRequestMethods.Ftp.UploadFile;
                errorMessage.AppendText("Connecting with Edison.. " + ftpURL + "\n");

                // This example assumes the FTP site uses anonymous logon.
                request.Credentials = new NetworkCredential(username, password);

                // Copy the contents of the file to the request stream
                byte[] fileContents;

                errorMessage.AppendText("Writing " + fullPath + " to" + ftpURL + "\n");
                fileContents = File.ReadAllBytes(fullPath);
                request.ContentLength = fileContents.Length;

                Stream requestStream = request.GetRequestStream();
                requestStream.Write(fileContents, 0, fileContents.Length);
                requestStream.Close();

                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                errorMessage.AppendText("Upload File Complete, status " + response.StatusDescription + "\n");

                response.Close();
                continueButton.Enabled = false;
            }
            catch(Exception f)
            {
                errorMessage.AppendText(f.ToString());
            }
        }

        private void BADWindow_Load(object sender, EventArgs e)
        {
            currentDirectory    = System.IO.Directory.GetCurrentDirectory();
            imageName.Text      = "Target Image File Descriptor";
            
        }

        private void browse_Click(object sender, EventArgs e)
        {
			//Open a file browser window for the user to choose an image
            OpenFileDialog ofd = new OpenFileDialog();
            errorMessage.Text = "";

            //File browser restraints ~ only image files are okay
            ofd.Filter = "Image Files(*.BMP; *.JPG; *.GIF; *.PNG)| *.BMP; *.JPG; *.GIF | All files(*.*) | *.*";
            ofd.Title = "Select an Image File";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                // assign the image file chosen to the file variable, seperate full path and image name.
                file = ofd.FileName;
                fullPath = file;
                file = file.Substring(file.LastIndexOf("\\")).Remove(0,1);
                imageName.Text = file;
                button1.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(!imageList.Items.Contains(file))
            {
                imageList.Items.Add(file, true);
                button1.Enabled = false;
                continueButton.Enabled = true;
            }
            else
            {
                errorMessage.Text = "Duplicate entry detected";
            }
        }

        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var FTPInfo = Prompt.ShowDialog("FTP Address", "Password", "FTP Settings");
        }

        private void edisonNetworkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var EdisonInfo = Prompt.ShowDialog("Edison SSID", "Password", "Edison Settings");
        }

        private void ssidToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void changeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var GoProInfo = Prompt.ShowDialog("GoPro SSID", "Password", "GoPro Settings");
        }

        private void imageList_SelectedIndexChanged(object sender, EventArgs e)
        {

            if(imageList.CheckedItems.Count == 0)
            {
                continueButton.Enabled = false;
                errorMessage.Text = "One image file must be selected";
                noneSelected = true;
            }
            else if (noneSelected.Equals(true))
            {
                errorMessage.Clear();
                noneSelected = false;
            }

            imagePreview.ImageLocation = fullPath;
            imagePreview.SizeMode = PictureBoxSizeMode.StretchImage;

        }
    }

    public static class Prompt
    {
        public static Tuple<String, String> ShowDialog(string field1, string field2, string caption)
        {
            Form prompt = new Form()
            {
                Width = 500,
                Height = 220,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = FormStartPosition.CenterScreen
            };
            Label textLabel = new Label() { Left = 50, Top = 20, Text = field1 };
            TextBox textBox = new TextBox() { Left = 50, Top = 50, Width = 400 };
            Label textLabel2 = new Label() { Left = 50, Top = 80, Text = field2 };
            TextBox textBox2 = new TextBox() { Left = 50, Top = 110, Width = 400 };
            Button confirmation = new Button() { Text = "Ok", Left = 350, Width = 100, Top = 140, DialogResult = DialogResult.OK };
            confirmation.Click += (sender, e) => { prompt.Close(); };
            prompt.Controls.Add(textBox);
            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(textLabel);
            prompt.Controls.Add(textBox2);
            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(textLabel2);
            prompt.AcceptButton = confirmation;
            prompt.Show();
            var tempData = Tuple.Create(textBox.Text, textBox2.Text);

            return tempData;
        }
    }

}
