Extra 2D Features Framework
===========================

1. Experimental 2D feature algorithms
2. Non-free 2D feature algorithms